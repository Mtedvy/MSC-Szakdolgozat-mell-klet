import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import quad
from matplotlib import cm
from scipy.stats import gamma
from scipy.stats import lognorm
import sys, os
sys.path.insert(0, os.path.join(os.path.abspath(sys.path[0]), "..", "lib"))

from pychartdir import *
from PIL import Image
import io
from scipy.stats import pareto

pareto_alpha = 2    # alakparaméter
pareto_scale = 100_000  # minimális lakásérték (Ft)
n_lakas = 1000         # lakásszám régiónként

def adjust_si_catxl(si_value, M, L):
    if si_value <= M:
        return si_value
    elif M < si_value < M + L:
        return M
    else:
        return si_value - L

def compute_scr_windstorm(ws_file, M, L):
    zones_df = pd.read_excel(ws_file, sheet_name="Zones")
    si_df = pd.read_excel(ws_file, sheet_name="SI_data")
    corr_zone_df = pd.read_excel(ws_file, sheet_name="Zone_Correlation")
    params_df = pd.read_excel(ws_file, sheet_name="Parameters")

    q_ws = params_df.loc[params_df["Parameter"] == "Q_windstorm (Market Factor)", "Value"].values[0]
    scr_ws_other = params_df.loc[params_df["Parameter"] == "SCR_windstorm_other", "Value"].fillna(0).values[0]
    
    # Pareto-alapú SI értékek generálása minden zónához
    for i in range(0,23):
        lakasok = pareto.rvs(b=pareto_alpha, scale=pareto_scale, size=n_lakas)
        lakasok = np.array([adjust_si_catxl(x, M, L) for x in lakasok])
        osszeg = np.sum(lakasok)
        si_df.loc[i, "SI_property"] = osszeg
        si_df.loc[i, "SI_onshore_property"] = osszeg

    merged_df = pd.merge(si_df, zones_df, on="Zone Name")
    merged_df["SI_ws"] = merged_df[["SI_property", "SI_onshore_property"]].sum(axis=1)
    merged_df["WSI_ws"] = merged_df["SI_ws"] * merged_df["W (windstorm)"]

    corr_matrix = corr_zone_df.set_index("Zone Name").astype(float).values
    wsi_vector = merged_df["WSI_ws"].values

    total = sum(corr_matrix[i][j] * wsi_vector[i] * wsi_vector[j]
                for i in range(len(wsi_vector)) for j in range(len(wsi_vector)))

    l_ws = q_ws * np.sqrt(total)
    scr_windstorm = np.sqrt(l_ws**2 + scr_ws_other**2)
    return scr_windstorm


def compute_scr_earthquake(eq_file, M, L):
    zones_df = pd.read_excel(eq_file, sheet_name="Zones")
    si_df = pd.read_excel(eq_file, sheet_name="SI_data")
    corr_zone_df = pd.read_excel(eq_file, sheet_name="Zone_Correlation")
    params_df = pd.read_excel(eq_file, sheet_name="Parameters")

    q_eq = params_df.loc[params_df["Parameter"] == "Q_eq (Market Factor)", "Value"].values[0]
    scr_eq_other = params_df.loc[params_df["Parameter"] == "SCR_eq_other", "Value"].fillna(0).values[0]
    
    # Pareto-alapú SI értékek generálása minden zónához
    for i in range(0,23):
        lakasok = pareto.rvs(b=pareto_alpha, scale=pareto_scale, size=n_lakas)
        lakasok = np.array([adjust_si_catxl(x, M, L) for x in lakasok])
        si_df.loc[i, "SI_property"] = np.sum(lakasok)
        si_df.loc[i, "SI_onshore_property"] = np.sum(lakasok)

    merged_df = pd.merge(si_df, zones_df, on="Zone Name")
    merged_df["SI_eq"] = merged_df[["SI_property", "SI_onshore_property"]].sum(axis=1)
    merged_df["WSI_eq"] = merged_df["SI_eq"] * merged_df["Cresta Relativity (W)"]

    corr_matrix = corr_zone_df.set_index("Zone Name").astype(float).values
    wsi_vector = merged_df["WSI_eq"].values

    total = sum(corr_matrix[i][j] * wsi_vector[i] * wsi_vector[j]
                for i in range(len(wsi_vector)) for j in range(len(wsi_vector)))

    l_eq = q_eq * np.sqrt(total)
    scr_earthquake = np.sqrt(l_eq**2 + scr_eq_other**2)
    return scr_earthquake

def compute_scr_flood(flood_file, M, L):
    si_df = pd.read_excel(flood_file, sheet_name="SI_data")
    corr_df = pd.read_excel(flood_file, sheet_name="Zone_Correlation")
    params_df = pd.read_excel(flood_file, sheet_name="Parameters")

    q_flood = params_df.loc[params_df["Parameter"] == "Q_flood (Market Factor)", "Value"].values[0]
    
    # Pareto-alapú SI értékek generálása minden zónához
    for i in range(0,23):
        lakasok = pareto.rvs(b=pareto_alpha, scale=pareto_scale, size=n_lakas)
        lakasok = np.array([adjust_si_catxl(x, M, L) for x in lakasok])
        osszeg_lakas = np.sum(lakasok)
        si_df.loc[i, "SI_property"] = osszeg_lakas
        si_df.loc[i, "SI_onshore_property"] = osszeg_lakas
    
    si_df["SI_flood"] = si_df[["SI_property", "SI_onshore_property"]].sum(axis=1)
    si_df["SI_flood"] += 1.5 * si_df["SI_motor"]
    si_df["WSI_flood"] = si_df["SI_flood"] * si_df["W_flood"]

    corr_matrix = corr_df.set_index("Zone Name").astype(float).values
    wsi_vector = si_df["WSI_flood"].values

    total = sum(corr_matrix[i][j] * wsi_vector[i] * wsi_vector[j]
                for i in range(len(wsi_vector)) for j in range(len(wsi_vector)))

    l_flood = q_flood * np.sqrt(total)
    scr_flood = max((0.65 + 0.45) * l_flood, (1.0 + 0.10) * l_flood)
    return scr_flood

def compute_scr_npproperty(file):
    df = pd.read_excel(file, sheet_name="Parameters")
    div = df.loc[df["Parameter"] == "DIV_npproperty", "Value"].values[0]
    p = df.loc[df["Parameter"] == "P_npproperty", "Value"].values[0]
    return 2.5 * (0.5 * div + 0.5) * p

def compute_scr_manmade(file, M, L):
    #df_motor = pd.read_excel(file, sheet_name="Motor_Liability")
    #df_marine_tanker = pd.read_excel(file, sheet_name="Marine_Tanker")
    #df_marine_platform = pd.read_excel(file, sheet_name="Marine_Platform")
    #df_aviation = pd.read_excel(file, sheet_name="Aviation")
    df_fire = pd.read_excel(file, sheet_name="Fire")
    #df_liability = pd.read_excel(file, sheet_name="Liability")
    #df_liability_corr = pd.read_excel(file, sheet_name="Liability_Corr")
    #df_credit = pd.read_excel(file, sheet_name="Credit")

    #N_a = df_motor.loc[df_motor["Parameter"] == "N_a", "Value"].values[0]
    #N_b = df_motor.loc[df_motor["Parameter"] == "N_b", "Value"].values[0]
    #scr_motor = max(6000000, 50000 * np.sqrt(N_a + 0.05 * N_b + 0.95 * min(N_b, 20000)))

    #scr_tanker = (df_marine_tanker["SI_hull"].fillna(0) +
    #              df_marine_tanker["SI_liab"].fillna(0) +
    #              df_marine_tanker["SI_pollution"].fillna(0)).max()
    #scr_platform = df_marine_platform["SI_total"].fillna(0).max()
    #scr_marine = np.sqrt(scr_tanker**2 + scr_platform**2)

    #scr_aviation = df_aviation["SI_total"].fillna(0).max()
    osszeg_total = 0
    for i in range(0,23):
        lakasok = pareto.rvs(b=pareto_alpha, scale=pareto_scale, size=n_lakas)
        lakasok = np.array([adjust_si_catxl(x, M, L) for x in lakasok])
        osszeg_total += np.sum(lakasok)
    df_fire["SI_total"] = osszeg_total
    scr_fire = df_fire["SI_total"].fillna(0).max()

    #df_liability["L_i"] = df_liability["f_liability"] * df_liability["P_liability"]
    #df_liability["SCR_i"] = df_liability["L_i"]
    #groups = df_liability["Group"].tolist()
    #scr_values = df_liability.set_index("Group")["SCR_i"].to_dict()
    #corr_matrix = df_liability_corr.set_index("Group").astype(float).loc[groups, groups].values
    #scr_vector = np.array([scr_values[g] for g in groups])
    #scr_liability = np.sqrt(np.sum(corr_matrix * np.outer(scr_vector, scr_vector)))

    #scr_default = df_credit.loc[df_credit["Parameter"] == "SCR_default", "Value"].fillna(0).values[0]
    #scr_recession = df_credit.loc[df_credit["Parameter"] == "SCR_recession", "Value"].fillna(0).values[0]
    #scr_credit = np.sqrt(scr_default**2 + scr_recession**2)

    #scr_components = [scr_motor, scr_marine, scr_aviation, scr_fire, scr_liability, scr_credit]
    #scr_components = [scr_motor,  scr_fire, scr_credit]
    scr_components=[scr_fire]
    scr_manmade = np.sqrt(np.sum([x**2 for x in scr_components]))
    return scr_manmade, scr_components

def compute_scr_other_nonlife():
    P = [0, 0, 0, 0, 0]
    c = [0, 0, 0, 0, 0]
    part1 = (c[0]*P[0] + c[1]*P[1])**2
    part2 = (c[2]*P[2])**2
    part3 = (c[3]*P[3])**2
    part4 = (c[4]*P[4])**2
    return np.sqrt(part1 + part2 + part3 + part4)

def generate_gamma_losses(shape, scale, size):
    """
    Gamma eloszlású káradatokat generál.
    shape: az alakparaméter (α)
    scale: a skála (θ)
    size: a generált adatok száma
    """
    return np.random.gamma(shape, scale, size)

def generate_lognormal_losses(mean, sigma, size):
    """
    Lognormális eloszlású káradatokat generál.
    mean: a lognormális eloszlás ln-középértéke
    sigma: a lognormális eloszlás szórása
    size: a generált adatok száma
    """
    return np.random.lognormal(mean, sigma, size)

def generate_negative_binomial_losses(n, p, size):
    """
    Kárszám-generálás negatív binomiális eloszlás alapján.
    Paraméterek:
    - n: a sikeres események száma, amíg megáll a folyamat
    - p: egy adott kísérlet sikerének valószínűsége
    - size: generált minták száma
    """
    return np.random.negative_binomial(n, p, size)

def generate_poisson_losses(lam, size):
    """
    Kárszám-generálás Poisson eloszlás alapján.
    Paraméterek:
    - lam: az események várható száma (lambda)
    - size: generált minták száma
    """
    return np.random.poisson(lam, size)

def expected_catxl_payout_formula(f_density, F_cdf, M, L):
    """
    E[Z(X)] kiszámítása CatXL esetén a képlet szerint.

    f_density: sűrűségfüggvény (PDF) – pl. scipy.stats.gamma(...).pdf
    F_cdf: eloszlásfüggvény (CDF) – pl. scipy.stats.gamma(...).cdf
    M: megtartási szint
    L: limit
    """

    # Első tag: integrál M és M+L között x*f(x) dx
    integral_term, _ = quad(lambda x: x * f_density(x), M, M + L)

    # Maradék korrekciós tagok
    term2 = -M * (1 - F_cdf(M))
    term3 = M * (1 - F_cdf(M + L))
    term4 = L * (1 - F_cdf(M + L))

    return integral_term + term2 + term3 + term4

def compute_scr_premium_reserve_gamma_catxl(
    P, P_last, FP_existing, FP_future, M, L,
    lambda_poisson, nb_n, nb_p,
    gamma_shape, gamma_scale,
    sim_size=10000,
    sigma_prem=0.08, sigma_res=0.10, DIV=1.0
):
    def catxl_adjust(x, M, L):
        return np.where(x <= M, x, M + np.maximum(0, x - M - L))    

    def simulate_losses(freq_dist, freq_params):
        total_losses = []
        for _ in range(sim_size):
            if freq_dist == 'poisson':
                n = np.random.poisson(freq_params['lam'])
            elif freq_dist == 'nb':
                n = np.random.negative_binomial(freq_params['n'], freq_params['p'])
            else:
                raise ValueError("Unsupported frequency distribution")

            if n == 0:
                total_losses.append(0)
                continue

            losses = np.random.gamma(gamma_shape, gamma_scale, n)
            adjusted = catxl_adjust(np.sum(losses), M, L)
            total_losses.append(adjusted)
        return np.mean(total_losses)

    V_prem = max(P, P_last) + FP_existing + FP_future

    V_res_gp = simulate_losses('poisson', {'lam': lambda_poisson})
    V_res_gnb = simulate_losses('nb', {'n': nb_n, 'p': nb_p})

    def compute_scr(V_prem, V_res):
        numerator = (sigma_prem**2) * V_prem**2 + sigma_prem * V_prem * sigma_res * V_res + (sigma_res**2) * V_res**2
        sigma_s = np.sqrt(numerator) / (V_prem + V_res)
        V_s = (V_prem + V_res) * (0.75 + 0.25 * DIV)
        return 3 * sigma_s * V_s

    scr_gp = compute_scr(V_prem, V_res_gp)
    scr_gnb = compute_scr(V_prem, V_res_gnb)

    return scr_gp, scr_gnb

def compute_scr_premium_reserve_lognorm_catxl(
    P, P_last, FP_existing, FP_future, M, L,
    lambda_poisson, nb_n, nb_p,
    lognorm_mean, lognorm_sigma,
    sim_size=10000,
    sigma_prem=0.08, sigma_res=0.10, DIV=1.0
):
    def catxl_adjust(x, M, L):
        return np.where(
            x <= M, x,
            np.where(x <= M + L, M, x - L)
        )

    def simulate_losses(freq_dist, freq_params):
        total_losses = []
        for _ in range(sim_size):
            if freq_dist == 'poisson':
                n = np.random.poisson(freq_params['lam'])
            elif freq_dist == 'nb':
                n = np.random.negative_binomial(freq_params['n'], freq_params['p'])
            else:
                raise ValueError("Unsupported frequency distribution")

            if n == 0:
                total_losses.append(0)
                continue

            losses = np.random.lognormal(lognorm_mean, lognorm_sigma, n)
            adjusted = catxl_adjust(np.sum(losses), M, L)
            total_losses.append(adjusted)
        return np.mean(total_losses)

    V_prem = max(P, P_last) + FP_existing + FP_future

    V_res_lp = simulate_losses('poisson', {'lam': lambda_poisson})
    V_res_lnb =  simulate_losses('nb', {'n': nb_n, 'p': nb_p})

    def compute_scr(V_prem, V_res):
        numerator = (sigma_prem**2) * V_prem**2 + sigma_prem * V_prem * sigma_res * V_res + (sigma_res**2) * V_res**2
        sigma_s = np.sqrt(numerator) / (V_prem + V_res)
        V_s = (V_prem + V_res) * (0.75 + 0.25 * DIV)
        return 3 * sigma_s * V_s

    scr_lp = compute_scr(V_prem, V_res_lp)
    scr_lnb = compute_scr(V_prem, V_res_lnb)

    return scr_lp, scr_lnb

def simulate_recoverables(freq_dist, freq_params, severity_dist, severity_params, M, L, sim_size=100000):
    recoverables = []
    for _ in range(sim_size):
        # kárszám generálása
        if freq_dist == 'poisson':
            n_claims = np.random.poisson(freq_params['lam'])
        elif freq_dist == 'nb':
            n_claims = np.random.negative_binomial(freq_params['n'], freq_params['p'])
        else:
            raise ValueError("Ismeretlen kárszám eloszlás")

        if n_claims == 0:
            recoverables.append(0)
            continue

        # kárnagyság generálása
        if severity_dist == 'lognorm':
            severities = np.random.lognormal(severity_params['mean'], severity_params['sigma'], n_claims)
        elif severity_dist == 'gamma':
            severities = np.random.gamma(severity_params['shape'], severity_params['scale'], n_claims)
        else:
            raise ValueError("Ismeretlen kárnagyság eloszlás")

        total_loss = np.sum(severities)

        # CatXL szerződés alapján várt térítés
        if total_loss <= M:
            rec = total_loss
        elif total_loss <= M + L:
            rec = M
        else:
            rec = M + (total_loss - M - L)

        recoverables.append(rec)

    return np.mean(recoverables)

def compute_lgd(rr_re, recoverables, rm_re, collateral):
    """
    LGD számítása partner nemteljesítés esetén.
    """
    raw_lgd = (1 - rr_re) * (recoverables + rm_re - collateral)
    return max(raw_lgd, 0)


def compute_scr_def_1(lgd_list, default_probs, quantile_factor=3.09):
  
    V_list = [
        ((1.5 * p * (1 - p)) / (2.5 - p)) * lgd**2
        for p, lgd in zip(default_probs, lgd_list)
    ]

    total_variance = sum(V_list)
    lgd_sum = sum(lgd_list)

    scr_def_1 = min(lgd_sum, quantile_factor * np.sqrt(total_variance))
    return scr_def_1

# rr_re: megtérülési arány (pl. 0.5)
# recoverables: elvárt megtérülés (pl. 10_000_000)
# rm_re: a kockázatcsökkentő hatás (pl. 2_000_000)
# collateral: a fedezet értéke (pl. 500_000)
# default_prob: a partner csődvalószínűsége (pl. 0.005 azaz 0.5%)

if __name__ == "__main__":
    
    wind_file = "szelvihar_sablon.xlsx"
    eq_file = "foldrenges_sablon.xlsx"
    flood_file = "arviz_sablon.xlsx"
    manmade_file = "manmade_cat_sablon.xlsx"
    nonprop_file = "nonprop_reins_sablon.xlsx"
    
    #SCR vb nélkül kiszámítása:
    # CatXL viszontbiztosítás paraméterei
    M = 100_000_000_000
    L = 0 
    scr_windstorm = compute_scr_windstorm(wind_file,M,L)
    scr_eq = compute_scr_earthquake(eq_file,M,L)
    scr_flood = compute_scr_flood(flood_file,M,L)
    scr_natcat = np.sqrt(scr_windstorm**2 + scr_eq**2 + scr_flood**2)
    scr_npp = compute_scr_npproperty(nonprop_file)
    scr_mm, mm_components = compute_scr_manmade(manmade_file,M,L)
    scr_other = compute_scr_other_nonlife()
    scr_nlcat = np.sqrt((scr_natcat + scr_npp)**2 + scr_mm**2 + scr_other**2)
    print(f"SCR vb nélkül: {scr_nlcat:,.2f} Eur")
    
    #Nettó díj vb nélkül:
    #Gamma percentilis
    shape = 6
    scale = 800_000_000
    mean_gamma = gamma.mean(a=shape, scale=scale)
    quantile_gamma = gamma.ppf(0.995, a=shape, scale=scale)
    #print(f"F^-1(99,5%)_gamma = {quantile_gamma:,.2f} Eur")
    
    #Lognormális percentilis:
    sigma = 0.35
    mean = 4_800_000_000   
    mu = np.log(mean) - (sigma**2) / 2
    mean_lognorm = lognorm.mean(s=sigma, scale=np.exp(mu))
    quantile_lognomr = lognorm.ppf(0.995, s=sigma, scale=np.exp(mu))
    #print(f"F^-1(99,5%)_lognorm = {quantile_lognomr:,.2f} Eur" )
    
    #Nettó Díj vb nélkül p=F^-1(99,5%)-SCR
    dij_netto_gamma = quantile_gamma-scr_nlcat
    #print(f"Nettó díj vb nélkül(gamma): {dij_netto_gamma:,.2f} Eur" )
    #Nettó Díj vb nélkül p=F^-1(99,5%)-SCR
    dij_netto_lognorm = quantile_lognomr-scr_nlcat
    #print(f"Nettó díj vb nélkül(lognorm): {dij_netto_lognorm:,.2f} Eur" )
    
    #Bruttó díj gamma
    loading = 0.20
    dij_brutto_gamma=(1+loading)*dij_netto_gamma
    #print(f"Bruttó díj vb nélkül(gamma): {dij_brutto_gamma:,.2f} Eur")
    #Bruttó díj lognorm
    loading = 0.20
    dij_brutto_lognorm=(1+loading)*dij_netto_lognorm
    #print(f"Bruttó díj vb nélkül(lognorm): {dij_brutto_lognorm:,.2f} Eur" )
    
    #SCR CatXL vb-vel:
    # CatXL viszontbiztosítás paraméterei
    M = 200_000
    L = 1_500_000  
    scr_windstorm = compute_scr_windstorm(wind_file,M,L)
    scr_eq = compute_scr_earthquake(eq_file,M,L)
    scr_flood = compute_scr_flood(flood_file,M,L)
    scr_natcat = np.sqrt(scr_windstorm**2 + scr_eq**2 + scr_flood**2)
    scr_npp = compute_scr_npproperty(nonprop_file)
    scr_mm, mm_components = compute_scr_manmade(manmade_file,M,L)
    scr_other = compute_scr_other_nonlife()
    scr_nlcat_vb = np.sqrt((scr_natcat + scr_npp)**2 + scr_mm**2 + scr_other**2)
    print(f"SCR {M} és {L} paraméterű CatXL vb-vel: {scr_nlcat_vb:,.2f}")
    
    #Bruttó díj CatXL vb esetén
    vb_potlek = 0.30
    
    #Bruttó díj gamma
    dist = gamma(a=shape, scale=scale)
    dij_brutto_gamma_vb=dij_brutto_gamma-((1/(1-vb_potlek))*expected_catxl_payout_formula(dist.pdf, dist.cdf, M, L))
    #print(f"Bruttó díj {M} és {L} paraméterű CatXL vb-vel (gamma): {dij_brutto_gamma_vb:,.2f} Eur" )
    #Bruttó díj lognorm
    dist = lognorm(s=sigma, scale=np.exp(mean))
    dij_brutto_lognorm_vb = dij_brutto_lognorm-((1/(1-vb_potlek))*expected_catxl_payout_formula(dist.pdf, dist.cdf, M, L))
    #print(f"Bruttó díj {M} és {L} paraméterű CatXL vb-vel (lognrom): {dij_brutto_lognorm_vb:,.2f} Eur" )
    

    #Díj és tartalékkokcázat vb-vel 
    results = {}
    #Kárszám paraméterek    
    lambda_poisson = 12000
    nb_n = 1502
    nb_p = 0.1112     
    
    # Gamma paraméterek
    gamma_shape = 5
    gamma_scale = 40_000

    # Lognormális paraméterek
    lognorm_mean = 12.2061
    lognorm_sigma = 0.35
    
    # Alap paraméterek
    P = dij_brutto_gamma_vb  # Következő évre várt megszolgált díj
    P_last = dij_brutto_gamma*0.85 # Előző év megszolgált bruttó díja
    FP_existing = dij_brutto_gamma_vb*0.9  # Meglévő szerződésekből származó jövőbeni díj  
    FP_future = dij_brutto_gamma_vb*0.1 # Új szerződésekből várható jövőbeni díj  
    
    scr_gp, scr_gnb = compute_scr_premium_reserve_gamma_catxl(
        P, P_last, FP_existing, FP_future, M, L,
        lambda_poisson, nb_n, nb_p,
        gamma_shape, gamma_scale
    )
    #print(f"SC_nl {M} és {L} paraméterű CatXL vb-vel (Poisson + Gamma):               {scr_gp:,.2f} Eur")
    #print(f"SC_nl {M} és {L} paraméterű CatXL vb-vel (Negatív binomiális + Gamma):    {scr_gnb:,.2f} Eur\n")
    results[f"SCR_nl CatXL (Poisson + Gamma) M={M}, L={L}"] = scr_gp
    results[f"SCR_nl CatXL (NB + Gamma) M={M}, L={L}"] = scr_gnb
    
    #Díj-tartalékkockázat lognorm eloszlás esetén
    # Alap paraméterek
    P = dij_brutto_lognorm_vb  # Következő évre várt megszolgált díj
    P_last = dij_brutto_lognorm*0.85 # Előző év megszolgált bruttó díja
    FP_existing = dij_brutto_lognorm_vb*0.9  # Meglévő szerződésekből származó jövőbeni díj  
    FP_future = dij_brutto_lognorm_vb*0.1 # Új szerződésekből várható jövőbeni díj
    
    scr_lp, scr_lnb = compute_scr_premium_reserve_lognorm_catxl(
        P, P_last, FP_existing, FP_future, M, L,
        lambda_poisson, nb_n, nb_p,
        lognorm_mean, lognorm_sigma
    )
    #print(f"SC_nl {M} és {L} paraméterű CatXL vb-vel (Poisson + Lognormális):         {scr_lp:,.2f} Eur")
    #print(f"SC_nl {M} és {L} paraméterű CatXL vb-vel (Negatív binomiális + Lognorm):  {scr_lnb:,.2f} Eur")
    results[f"SCR_nl CatXL (Poisson + Lognormális) M={M}, L={L}"] = scr_lp
    results[f"SCR_nl CatXL (NB + Lognormális) M={M}, L={L}"] = scr_lnb
    
    #Partner kockázat
    #Partner kockázat Poisson + Gamma  AAA
    recoverables_pg = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_pg = compute_lgd(0.5, recoverables_pg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pg = compute_scr_def_1([lgd_pg], [0.00002])
    results["SCR_def_Poisson+Gamma AAA"] = scr_def_pg
    #print(f"SCR_def_Poisson + Gamma: {scr_def_pg:,.2f} EUR")
    
    #Partner kockázat Poisson + Lognormális AAA
    recoverables_pl = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_pl = compute_lgd(0.5, recoverables_pl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pl = compute_scr_def_1([lgd_pl], [0.00002])
    results["SCR_def_Poisson + Lognormális AAA"] = scr_def_pl
    #print(f"SCR_def_Poisson + Lognormális: {scr_def_pl:,.2f} EUR")
    
    #Partner kockázat Negatív binomiális + Gamma AAA
    recoverables_nbg = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_nbg = compute_lgd(0.5, recoverables_nbg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbg = compute_scr_def_1([lgd_nbg], [0.00002])
    results["SCR_def_NB + Gamma AAA"] = scr_def_nbg
    #print(f"SCR_def_NB + Gamma: {scr_def_nbg:,.2f} EUR")
    
    #  Negatív binomiális + Lognormális AAA
    recoverables_nbl = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_nbl = compute_lgd(0.5, recoverables_nbl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbl = compute_scr_def_1([lgd_nbl], [0.00002])
    results["SCR_def_NB + Lognormális AAA"] = scr_def_nbl
    #print(f"SCR_def_NB + Lognormális: {scr_def_nbl:,.2f} EUR")
    
    
    #Partner kockázat Poisson + Gamma  A
    recoverables_pg = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_pg = compute_lgd(0.5, recoverables_pg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pg = compute_scr_def_1([lgd_pg], [0.0005])
    results["SCR_def_Poisson+Gamma A"] = scr_def_pg
    #print(f"SCR_def_Poisson + Gamma: {scr_def_pg:,.2f} EUR")
    
    #Partner kockázat Poisson + Lognormális A
    recoverables_pl = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_pl = compute_lgd(0.5, recoverables_pl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pl = compute_scr_def_1([lgd_pl], [0.0005])
    results["SCR_def_Poisson + Lognormális A"] = scr_def_pl
    #print(f"SCR_def_Poisson + Lognormális: {scr_def_pl:,.2f} EUR")
    
    #Partner kockázat Negatív binomiális + Gamma A
    recoverables_nbg = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_nbg = compute_lgd(0.5, recoverables_nbg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbg = compute_scr_def_1([lgd_nbg], [0.0005])
    results["SCR_def_NB + Gamma A"] = scr_def_nbg
    #print(f"SCR_def_NB + Gamma: {scr_def_nbg:,.2f} EUR")
    
    #  Negatív binomiális + Lognormális A
    recoverables_nbl = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_nbl = compute_lgd(0.5, recoverables_nbl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbl = compute_scr_def_1([lgd_nbl], [0.0005])
    results["SCR_def_NB + Lognormális A"] = scr_def_nbl
    #print(f"SCR_def_NB + Lognormális: {scr_def_nbl:,.2f} EUR")
    
    
    #Partner kockázat Poisson + Gamma  BBB
    recoverables_pg = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_pg = compute_lgd(0.5, recoverables_pg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pg = compute_scr_def_1([lgd_pg], [0.0024])
    results["SCR_def_Poisson+Gamma BBB"] = scr_def_pg
    #print(f"SCR_def_Poisson + Gamma: {scr_def_pg:,.2f} EUR")
    
    #Partner kockázat Poisson + Lognormális BBB
    recoverables_pl = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_pl = compute_lgd(0.5, recoverables_pl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pl = compute_scr_def_1([lgd_pl], [0.0024])
    results["SCR_def_Poisson + Lognormális BBB"] = scr_def_pl
    #print(f"SCR_def_Poisson + Lognormális: {scr_def_pl:,.2f} EUR")
    
    #Partner kockázat Negatív binomiális + Gamma BBB
    recoverables_nbg = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_nbg = compute_lgd(0.5, recoverables_nbg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbg = compute_scr_def_1([lgd_nbg], [0.0024])
    results["SCR_def_NB + Gamma BBB"] = scr_def_nbg
    #print(f"SCR_def_NB + Gamma: {scr_def_nbg:,.2f} EUR")
    
    #  Negatív binomiális + Lognormális BBB
    recoverables_nbl = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_nbl = compute_lgd(0.5, recoverables_nbl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbl = compute_scr_def_1([lgd_nbl], [0.0024])
    results["SCR_def_NB + Lognormális BBB"] = scr_def_nbl
    #print(f"SCR_def_NB + Lognormális: {scr_def_nbl:,.2f} EUR")
    
    
    #Partner kockázat Poisson + Gamma  B
    recoverables_pg = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_pg = compute_lgd(0.5, recoverables_pg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pg = compute_scr_def_1([lgd_pg], [0.0120])
    results["SCR_def_Poisson+Gamma B"] = scr_def_pg
    #print(f"SCR_def_Poisson + Gamma: {scr_def_pg:,.2f} EUR")
    
    #Partner kockázat Poisson + Lognormális B
    recoverables_pl = simulate_recoverables(
    freq_dist='poisson',
    freq_params={'lam': lambda_poisson},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_pl = compute_lgd(0.5, recoverables_pl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_pl = compute_scr_def_1([lgd_pl], [0.0120])
    results["SCR_def_Poisson + Lognormális B"] = scr_def_pl
    #print(f"SCR_def_Poisson + Lognormális: {scr_def_pl:,.2f} EUR")
    
    #Partner kockázat Negatív binomiális + Gamma B
    recoverables_nbg = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='gamma',
    severity_params={'shape': gamma_shape, 'scale': gamma_scale},
    M=M, L=L
    )
    lgd_nbg = compute_lgd(0.5, recoverables_nbg, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbg = compute_scr_def_1([lgd_nbg], [0.0120])
    results["SCR_def_NB + Gamma B"] = scr_def_nbg
    #print(f"SCR_def_NB + Gamma: {scr_def_nbg:,.2f} EUR")
    
    #  Negatív binomiális + Lognormális B
    recoverables_nbl = simulate_recoverables(
    freq_dist='nb',
    freq_params={'n': nb_n, 'p': nb_p},
    severity_dist='lognorm',
    severity_params={'mean': lognorm_mean, 'sigma': lognorm_sigma},
    M=M, L=L
    )
    lgd_nbl = compute_lgd(0.5, recoverables_nbl, scr_nlcat - scr_nlcat_vb, 0)
    scr_def_nbl = compute_scr_def_1([lgd_nbl], [0.0120])
    results["SCR_def_NB + Lognormális B"] = scr_def_nbl
    #print(f"SCR_def_NB + Lognormális: {scr_def_nbl:,.2f} EUR")
    
    
    # --- Exportálás Excelbe ---
    df = pd.DataFrame(list(results.items()), columns=["Változónév", "Érték (EUR)"])
    df.to_excel("scr_catxl_dij_tartalek.xlsx", index=False)

    print("Exportálás kész: scr_catxl_dij_tartalek.xlsx")
    
    #print(f"SCR_def_gamma+SCR_vb+SCR_nl_(Poisson + Gamma) AAA : {scr_def+scr_nlcat_vb+scr_gp:,.2f} EUR")
    #print(f"SCR_def_gamma+SCR_vb+SCR_nl_(Negatív binomiális + Gamma) AAA: {scr_def+scr_nlcat_vb+scr_gnb:,.2f} EUR")
   
   
    